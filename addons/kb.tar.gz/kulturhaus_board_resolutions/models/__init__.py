# -*- coding: utf-8 -*-

from . import board_resolution
from . import project_inherit
from . import res_partner_inherit