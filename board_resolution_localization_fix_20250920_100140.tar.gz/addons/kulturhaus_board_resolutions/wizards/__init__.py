# -*- coding: utf-8 -*-

from . import create_resolution_wizard