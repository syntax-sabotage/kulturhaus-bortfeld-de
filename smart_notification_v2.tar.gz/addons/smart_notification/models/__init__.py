# -*- coding: utf-8 -*-
# Part of Smart Notification. See LICENSE file for full copyright and licensing details.

from . import notification_profile
from . import res_users
from . import mail_followers
from . import mail_thread