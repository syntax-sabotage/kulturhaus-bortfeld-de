# -*- coding: utf-8 -*-
from . import apply_preferences_wizard